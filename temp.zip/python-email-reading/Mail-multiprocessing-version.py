import sys
import itertools
import collections
from timeit import default_timer as timer
import multiprocessing
import Mail

def fetching(ids_list):
    raw_mails = Mail.fetch_emails(ids_list)
    return raw_mails

def cleaning(raw_email):

    transaction_details = Mail.cleaning(raw_email)
    return transaction_details

def formatting(transaction_details):

    # cleaning the data of empty fileds and re formatting it into CSV
    transaction_details = [ele for ele in transaction_details if (ele not in ("", " "))] 
    current_transaction = Mail.formatting(transaction_details)

    return current_transaction


if __name__ == "__main__":

    start_time = timer()

    mail = Mail.setup("mazen-almazni@hotmail.com", "almazni012013", "outlook.office365.com", "BAB")
    type, data = mail.search(None, 'ALL')
    
    mail_ids = data[0]
    id_list = mail_ids.split()

    pool = multiprocessing.Pool()
    chunksize = 4
    
    print("Fetching emails...")

    start = timer()
    emails_list = fetching(id_list)
    FETCHING_TIME = timer() - start

    print("Cleaning emails...")

    start = timer()
    cleaned_emails = pool.map(cleaning, emails_list, chunksize=chunksize)
    CLEANING_TIME = timer() - start

    print("Formatting emails...")

    start = timer()
    formatted_emails = pool.map(formatting, cleaned_emails, chunksize=chunksize)
    FORMATTING_TIME = timer() - start

    print("Writing emails...")
    Mail.write_results(formatted_emails)
    start = timer()
    
    WRITING_TIME = timer() - start

    end_time = timer()

    print("\Fetching time = {} s".format(FETCHING_TIME))
    print("Cleaning time = {} s".format(CLEANING_TIME))
    print("Formatting time = {} s".format(FORMATTING_TIME))
    print("Writing time = {} s".format(WRITING_TIME))
    print("Total running time = {} s".format(end_time - start_time))