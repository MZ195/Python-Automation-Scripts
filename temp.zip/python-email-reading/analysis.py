import pandas as ps

processing_file = ps.read_csv("something.csv")

print(processing_file.head())